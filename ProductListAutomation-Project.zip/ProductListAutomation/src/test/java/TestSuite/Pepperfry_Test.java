package TestSuite;
import Pages.Pepperfry;

public class Pepperfry_Test 
{
	public static void main(String[] args)
	{
		Pepperfry obj=new Pepperfry();
	     obj.driverSetup();
	     obj.openUrl();
	     obj.validateText();
	     obj.selectFurniture();
	     obj.selectBenches();
	     obj.fetchBenchDetails();
	     obj.printBenchDetails();
	     
	     obj.validateIndustrialBenchesCount();
	     obj.closeBrowser();
		
	}

}
