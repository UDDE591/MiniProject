package Pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Base.Base;
@SuppressWarnings("unused")
public class Pepperfry extends Base 
{
	public void openUrl()
	{
		driver.get("https://www.pepperfry.com/");
	}
	public void validateText()
	{
		if(driver.getTitle().contains("Online Furniture Shopping Store"))
		    //Pass
		    System.out.println("Page title contains Online Furniture Shopping Store");
		else
		    //Fail
		    System.out.println("Page title doesn't contains Online Furniture Shopping Store ");
	}
	public void selectFurniture()
	{
		driver.findElement(By.xpath("//div[@id='menu_wrapper']/ul/li/a")).click();
	}
	public void selectBenches() 
	{
		driver.findElement(By.xpath("//a[text()='Seating']")).click();
		driver.findElement(By.linkText("Benches")).click();
	}
	List<WebElement> lst1;
	List<WebElement> lst2;

    public void fetchBenchDetails() 
    {
		lst1=driver.findElements(By.xpath("//h5[@class='clip-maincat-ttl pf-margin-0 font-14']"));
		lst2=driver.findElements(By.xpath("//p[@class='clip-catitem-strtngfrm pf-margin-0 font-12']"));
	}
	public void printBenchDetails()
	{
		System.out.println();
		System.out.println("No. of benches with respect to category:");
		for(int i=0;i<lst1.size();i++)
		{
			System.out.print(lst1.get(i).getText());
			System.out.print(": ");
			//System.out.println(lst2.get(i).getText());
			System.out.println(lst2.get(i).getText().replaceAll(" ","").replaceAll("[A-Za-z]",""));
	    }
	}		
	public void validateIndustrialBenchesCount()
		{
		    System.out.println();
			System.out.print("Is Count of Industrial Benches greater than one? -->  ");
			for(int i=0;i<lst1.size();i++)
			{
				if(lst1.get(i).getText().equals("Industrial Benches"))
				{
				   if(Integer.parseInt(lst2.get(i).getText().replaceAll(" ","").replaceAll("[A-Za-z]",""))>1)
					   System.out.println("YES");
				   else
					   System.out.println("NO");
		        }
             }	

         }
	public static void main(String[] args)
	{
		Pepperfry obj=new Pepperfry();
	     obj.driverSetup();
	     obj.openUrl();
	     obj.validateText();
	     obj.selectFurniture();
	     obj.selectBenches();
	     obj.fetchBenchDetails();
	     obj.printBenchDetails();
	     obj.validateIndustrialBenchesCount();
	     obj.closeBrowser();
		
	}

}
